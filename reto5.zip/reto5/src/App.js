import React, { useState } from 'react';
import copy from 'copy-to-clipboard';
import { Row } from 'react-bootstrap';

import './App.css';

function App() {
  const [contraseña, setContraseña] = useState('');
  const [length, setLength] = useState('4');
  const [upper, setUpper] = useState(false);
  const [lower, setLower] = useState(false);
  const [numbers, setNumbers] = useState(false);
  const [special, setSpecial] = useState(false);

  const caracteresU = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const caracteresL = 'abcdefghijklmnopqrstuvwxyz';
  const caracteresS = '!@#$%^&*';
  const caracteresN = '0123456789';
  var caracteresSelected = '';

  const copiarAlPortapapeles = () => {
    copy(contraseña);
    alert("Texto copiado al portapapeles");
  };

  const generarContraseña = () => {
    
    //const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let nuevaContraseña = '';
    for (let i = 0; i < Number(length); i++) {
      const randomIndex = Math.floor(Math.random() * caracteresSelected.length);
      console.log(caracteresSelected);

      if(upper === true){
        caracteresSelected = caracteresSelected.concat(caracteresU);
      }
      else{
        caracteresSelected = caracteresSelected.replace(caracteresU, '');
      }

      if(lower === true){
        caracteresSelected = caracteresSelected.concat(caracteresL);
      }
      else{
        caracteresSelected = caracteresSelected.replace(caracteresL, '');
      }

      if(numbers === true){
        caracteresSelected = caracteresSelected.concat(caracteresN);
      }
      else{
        caracteresSelected = caracteresSelected.replace(caracteresN, '');
      }

      if(special === true){
        caracteresSelected = caracteresSelected.concat(caracteresS);
      }
      else{
        caracteresSelected = caracteresSelected.replace(caracteresS, '');
      }

      if (caracteresSelected.length !== 0){
        nuevaContraseña += caracteresSelected[randomIndex];
      }
      
    }
    setContraseña(nuevaContraseña);
  };

  const handleChangeLongitud = (e) => {
    setLength(e.target.value);
    generarContraseña();
  };

  const handleChangeU = (e) => {
    //console.log("Upper: " + upper)
    
    setUpper(!upper);

    if(upper === false){
      caracteresSelected = caracteresSelected.replace(caracteresU,'');
    }
    console.log(caracteresSelected)
    generarContraseña();

  }

  const handleChangeL = (e) => {
    setLower(!lower);
    
    if(lower === false){
      caracteresSelected = caracteresSelected.replace(caracteresL,'');
    }
    console.log(caracteresSelected)
    generarContraseña();
  };

  const handleChangeN = (e) => {
    setNumbers(!numbers);
    
    if(numbers === false){
      caracteresSelected = caracteresSelected.replace(caracteresN,'');
    }
    console.log(caracteresSelected)
    generarContraseña();
  };

  const handleChangeS = (e) => {
    setSpecial(!special);
    if(special === false){
      caracteresSelected = caracteresSelected.replace(caracteresS,'');
    }
    console.log(caracteresSelected)
    generarContraseña();
  };

  return (
    <div className='passwordgen'>
      <Row>

        <h2>Generador de Contraseñas</h2>
        <button onClick={generarContraseña}>Generar Contraseña</button>
        <p>Contraseña: {contraseña}</p>
        <button onClick={copiarAlPortapapeles}>Copy</button>

      </Row>


      <Row>

        <label>
          Longitud de la Contraseña:
          <input 
            type="range" 
            min="4" 
            max="30" 
            value={length} 
            onChange={handleChangeLongitud} 
          />
          <span>{length}</span>
        </label>

      </Row>
        

      <Row>

        <label>
          <input 
            type="checkbox" 
            checked={upper} 
            onChange={handleChangeU} 
          />
          Uppercase
        </label>

      </Row>
      
      <Row>

      <label>
        <input 
          type="checkbox" 
          checked={lower} 
          onChange={handleChangeL} 
        />
        Lowercase
      </label>

      </Row>
      
      <Row>
      <label>
        <input 
          type="checkbox" 
          checked={numbers} 
          onChange={handleChangeN} 
        />
        Numbers
      </label>
      </Row>

      <Row>

      <label>
        <input 
          type="checkbox" 
          checked={special} 
          onChange={handleChangeS} 
        />
        Special Characters
      </label>
      </Row>

      
    </div>
  );
  
}

export default App;

import React from 'react';
import { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Row, Col } from 'react-bootstrap';

function ProgressBarM(){

    const [progressV, setProgress] = useState('0');
    const handleChange = (e) => {
        setProgress(e.target.value); // Cuando el input cambia, actualizamos el estado
    };
    
    return (
        <div className = 'progress_bar'>
            
            <Row>
                <label>Proggress Bar</label>
            </Row>
            <Row>
                <progress max="100" value={progressV}></progress>
            </Row>
            <Row>
                <label>Input Percentage</label>

                <input
                    className=''
                    type="text"
                    value={progressV}
                    onChange={handleChange}
                />
            </Row>
            
        </div>
    );
}

export default ProgressBarM;
import ProgressBarM from './ProgressBarM';
import './App.css';

function App() {
  return (
    <ProgressBarM></ProgressBarM>
  );
}

export default App;

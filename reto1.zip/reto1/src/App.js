import './App.css';
import Nb from './components/Nb.js'

function App() {
  return (
    <div><Nb o={false}/><Nb o={true}/></div>
  );
}

export default App;

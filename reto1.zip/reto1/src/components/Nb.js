import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function Nb (props){

    if(props.o === false){
        return(
            <nav className="navbar">
                <ul className="navbar-list">
                    <li className="navbar-item">Home</li>
                    <li className="navbar-item">Features</li>
                    <li className="navbar-item">Pricing</li>
                    <li className="navbar-item">About</li>
                    
                </ul>
                <label className="navbar-label"> </label>
                <input type="text" className="navbar-input" placeholder="Search"/>
                <button className="navbar-button">Search</button>
            </nav>
        );
    }
    else{
        return(
            <nav className="navbar">
                <button className="navbar-button">Search</button>
                <input type="text" className="navbar-input" placeholder="Search"/>
                <label className="navbar-label"> </label>
                <ul className="navbar-list">
                    <li className="navbar-item">About</li>
                    <li className="navbar-item">Pricing</li>
                    <li className="navbar-item">Features</li>
                    <li className="navbar-item">Home</li>
                    <li className="navbar-item"><h5>NavBar</h5></li>                    
                </ul>
            </nav>
        );
    }
    
    
}

export default Nb;